# Claude K1 — DeepSeek V4 Pro

Claude-style chat UI powered by `deepseek-ai/deepseek-v4-pro` through NVIDIA NIM.

## Deploy from GitHub to Vercel

> This project requires a server API route and therefore will **not** work on GitHub Pages alone. GitHub stores the repository; Vercel runs the `/api/nvidia-chat` function.

1. Extract the ZIP.
2. Create a new GitHub repository.
3. Upload **all extracted files and folders** to the repository root. Keep the `api/` folder intact.
4. In Vercel, choose **Add New → Project**, import the GitHub repository, and keep the Framework Preset as **Other**.
5. **Required:** add `NVIDIA_API_KEY` in **Vercel → Project Settings → Environment Variables** for Production, Preview, and Development.
6. Deploy.
7. Verify `https://YOUR-DOMAIN.vercel.app/api/health` returns JSON with `"ok": true`.
8. Open the site and send a message. DeepSeek V4 Pro can take two to three minutes on its first cold request.

## Required production files

```text
index.html
vercel.json
package.json
api/
  health.js
  nvidia-chat.js
  run-command.js
  web-search.js
command_workspace/
  README.txt
```

## Local use

Keep `index.html` and `server.py` in the same folder, then run:

```bash
python3 server.py
```

The local app opens at `http://127.0.0.1:8000/`.

## Security

For production, rotate any API key previously exposed in browser source or chat history, store the replacement as Vercel's `NVIDIA_API_KEY` environment variable, and remove the old public key from `index.html`.
