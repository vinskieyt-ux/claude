module.exports = async function handler(_req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Cache-Control', 'no-store');
  res.status(200).json({ ok: true, runtime: 'vercel', provider: 'NVIDIA NIM', model: 'deepseek-ai/deepseek-v4-pro', tools: ['run_command', 'web_search', 'web_fetch'] });
};
