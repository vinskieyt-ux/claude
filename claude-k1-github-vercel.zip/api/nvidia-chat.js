const NVIDIA_CHAT_URL = 'https://integrate.api.nvidia.com/v1/chat/completions';

// Self-contained Vercel proxy for index.html. Keep this file at
// /api/nvidia-chat.js so the browser can POST to /api/nvidia-chat.
module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Type');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('X-Accel-Buffering', 'no');

  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST, OPTIONS');
    return res.status(405).json({ error: { message: 'Method not allowed' } });
  }

  const authorization = String(req.headers.authorization || '');
  const bearer = authorization.match(/^Bearer\s+(.+)$/i)?.[1]?.trim() || '';
  const key = process.env.NVIDIA_API_KEY || bearer;
  if (!key) return res.status(401).json({ error: { message: 'Missing NVIDIA_API_KEY environment variable' } });

  try {
    const upstream = await fetch(NVIDIA_CHAT_URL, {
      method: 'POST',
      headers: {
        authorization: `Bearer ${key}`,
        'content-type': 'application/json',
        accept: req.body?.stream ? 'text/event-stream' : 'application/json',
        'user-agent': 'OpenAI/Node',
      },
      body: JSON.stringify(req.body || {}),
    });

    res.status(upstream.status);
    res.setHeader('Content-Type', upstream.headers.get('content-type') || 'application/json');

    if (!upstream.body) return res.end(await upstream.text());
    const reader = upstream.body.getReader();
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      res.write(Buffer.from(value));
    }
    return res.end();
  } catch (error) {
    return res.status(502).json({
      error: {
        type: 'proxy_error',
        message: error instanceof Error ? error.message : String(error),
      },
    });
  }
};
