function decodeXml(value = '') {
  return value
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/<[^>]*>/g, '')
    .trim();
}

function tag(item, name) {
  const match = item.match(new RegExp(`<${name}>([\\s\\S]*?)<\\/${name}>`, 'i'));
  return decodeXml(match ? match[1] : '');
}

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST, OPTIONS');
    return res.status(405).json({ ok: false, error: 'Method not allowed' });
  }

  const started = Date.now();
  const query = String(req.body?.query || '').trim().replace(/\s+/g, ' ');
  const limit = Math.max(1, Math.min(Number(req.body?.max_results) || 5, 8));
  if (!query || query.length > 500) {
    return res.status(400).json({ ok: false, query, results: [], error: 'Invalid search query' });
  }

  try {
    const url = `https://www.bing.com/search?q=${encodeURIComponent(query)}&format=rss`;
    const response = await fetch(url, {
      headers: {
        'user-agent': 'Mozilla/5.0 (compatible; ArenaAgentSearch/1.0)',
        accept: 'application/rss+xml,application/xml,text/xml',
      },
    });
    if (!response.ok) throw new Error(`Bing HTTP ${response.status}`);
    const xml = await response.text();
    const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/gi)].slice(0, limit);
    const results = items.map((match) => ({
      title: tag(match[1], 'title'),
      url: tag(match[1], 'link'),
      snippet: tag(match[1], 'description'),
    })).filter((item) => item.title && /^https?:\/\//.test(item.url));

    res.setHeader('Cache-Control', 'no-store');
    res.status(200).json({
      ok: true,
      query,
      provider: 'Bing Search RSS',
      results,
      result_count: results.length,
      duration_ms: Date.now() - started,
    });
  } catch (error) {
    res.status(502).json({
      ok: false,
      query,
      provider: 'Bing Search RSS',
      results: [],
      error: error instanceof Error ? error.message : String(error),
      duration_ms: Date.now() - started,
    });
  }
};
