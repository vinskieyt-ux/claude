This is the restricted workspace used by Claude's run_command tool.

Allowed commands: pwd, ls, cat, head, tail, wc, grep, echo, and read-only curl for public HTTP(S) URLs.
Commands cannot use shell operators, redirection, absolute paths, parent paths, or arbitrary programs.
