#!/usr/bin/env python3
"""Serve the Claude-style UI, restricted command tool, and real web search tool.

Run: python3 server.py
Open: http://127.0.0.1:8000

The command endpoint is read-only by design. It does not invoke a shell and only
allows a small set of inspection commands inside ./command_workspace.
"""

from __future__ import annotations

import ipaddress
import json
import os
from pathlib import Path
import re
import shlex
import socket
import subprocess
import threading
import time
import webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlencode, urlparse
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT / "command_workspace"
WORKSPACE.mkdir(exist_ok=True)

HOST = "127.0.0.1"
PORT = int(os.environ.get("PORT", "8000"))
MAX_COMMAND_CHARS = 1_000
MAX_OUTPUT_CHARS = 40_000
TIMEOUT_SECONDS = 12
SEARCH_TIMEOUT_SECONDS = 15
MAX_SEARCH_RESULTS = 8
ALLOWED_COMMANDS = {"pwd", "ls", "cat", "head", "tail", "wc", "grep", "echo", "curl"}
AIAND_MESSAGES_UPSTREAM = "https://api.aiand.com/v1/messages"
AIAND_CHAT_UPSTREAM = "https://api.aiand.com/v1/chat/completions"
FORBIDDEN_FIND_STYLE_OPTIONS = {"-exec", "-execdir", "-delete", "-fprint", "-fprintf", "-ok", "-okdir"}
SHELL_META = set(";&|><`\n\r\x00")
URL_RE = re.compile(r"https?://[^\s\"'()\\]+", re.IGNORECASE)
MARKDOWN_URL_RE = re.compile(r"\[\s*(https?://[^\]\\]+)\\?\]\(\s*(https?://[^)\\]+)\\?\)", re.IGNORECASE)


def validate_public_url(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("curl only supports public http:// or https:// URLs.")
    if parsed.username or parsed.password:
        raise ValueError("URLs containing credentials are disabled.")
    host = parsed.hostname.lower().rstrip(".")
    if host in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
        raise ValueError("Local and private-network URLs are disabled.")
    try:
        addresses = {info[4][0] for info in socket.getaddrinfo(host, parsed.port or 443, type=socket.SOCK_STREAM)}
    except socket.gaierror as exc:
        raise ValueError(f"Could not resolve URL host: {host}") from exc
    for address in addresses:
        ip = ipaddress.ip_address(address)
        if not ip.is_global:
            raise ValueError("Local, private, loopback, and reserved network addresses are disabled.")
    return url


def normalize_curl_command(command: str) -> tuple[list[str], str] | None:
    if not command.lstrip().startswith("curl "):
        return None
    # Models sometimes wrap a URL as Markdown: [https://a](https://a). Remove
    # that formatting and then rebuild a fixed, read-only curl invocation.
    cleaned = MARKDOWN_URL_RE.sub(lambda match: match.group(2), command.replace("\\)", ")").replace("\\]", "]"))
    urls = URL_RE.findall(cleaned)
    if not urls:
        raise ValueError("curl requires a public HTTP(S) URL.")
    url = validate_public_url(urls[-1].rstrip('.,;'))
    argv = ["curl", "-sS", "-L", "--max-time", "10", "--connect-timeout", "5", url]
    return argv, " ".join(shlex.quote(part) for part in argv)


def validate_command(command: str) -> tuple[list[str], str]:
    if not isinstance(command, str) or not command.strip():
        raise ValueError("No command was provided.")
    if len(command) > MAX_COMMAND_CHARS:
        raise ValueError(f"Command exceeds {MAX_COMMAND_CHARS} characters.")

    curl_command = normalize_curl_command(command)
    if curl_command:
        return curl_command

    if any(character in command for character in SHELL_META) or "$(" in command:
        raise ValueError("Shell operators, redirection, substitution, and multiline commands are disabled.")

    try:
        argv = shlex.split(command, posix=True)
    except ValueError as exc:
        raise ValueError(f"Could not parse command: {exc}") from exc
    if not argv:
        raise ValueError("No command was provided.")
    if argv[0] not in ALLOWED_COMMANDS:
        allowed = ", ".join(sorted(ALLOWED_COMMANDS))
        raise ValueError(f"Command '{argv[0]}' is not allowed. Available commands: {allowed}.")

    for argument in argv[1:]:
        if argument in FORBIDDEN_FIND_STYLE_OPTIONS:
            raise ValueError(f"Option '{argument}' is disabled.")
        if argument.startswith(("/", "~")):
            raise ValueError("Absolute and home-directory paths are disabled.")
        parts = Path(argument).parts
        if ".." in parts:
            raise ValueError("Parent-directory traversal is disabled.")
    return argv, " ".join(shlex.quote(part) for part in argv)


def run_command(command: str) -> dict[str, object]:
    started = time.monotonic()
    try:
        argv, normalized_command = validate_command(command)
    except ValueError as exc:
        return {
            "ok": False,
            "command": command,
            "stdout": "",
            "stderr": str(exc),
            "return_code": 126,
            "duration_ms": round((time.monotonic() - started) * 1000),
        }

    try:
        completed = subprocess.run(
            argv,
            cwd=WORKSPACE,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=TIMEOUT_SECONDS,
            shell=False,
            env={"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"},
            start_new_session=True,
        )
        stdout = completed.stdout
        stderr = completed.stderr
        return_code = completed.returncode
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout or ""
        stderr = (exc.stderr or "") + f"\nCommand timed out after {TIMEOUT_SECONDS} seconds."
        return_code = 124
    except Exception as exc:  # Return errors to Claude as tool results.
        stdout = ""
        stderr = f"Command runner error: {exc}"
        return_code = 1

    truncated = False
    if len(stdout) + len(stderr) > MAX_OUTPUT_CHARS:
        remaining = MAX_OUTPUT_CHARS
        stdout = stdout[:remaining]
        remaining -= len(stdout)
        stderr = stderr[: max(0, remaining)]
        truncated = True

    return {
        "ok": return_code == 0,
        "command": normalized_command,
        "stdout": stdout,
        "stderr": stderr,
        "return_code": return_code,
        "duration_ms": round((time.monotonic() - started) * 1000),
        "truncated": truncated,
    }


def search_web(query: str, max_results: int = 5) -> dict[str, object]:
    started = time.monotonic()
    query = " ".join(str(query or "").split())
    if not query:
        return {"ok": False, "query": query, "results": [], "error": "No search query was provided."}
    if len(query) > 500:
        return {"ok": False, "query": query[:500], "results": [], "error": "Search query exceeds 500 characters."}

    limit = max(1, min(int(max_results or 5), MAX_SEARCH_RESULTS))
    # Bing exposes a public RSS representation of normal search results. It is
    # server-fetched, requires no browser CORS workaround, and returns real URLs.
    url = "https://www.bing.com/search?" + urlencode({"q": query, "format": "rss"})
    request = Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 (compatible; ArenaAgentSearch/1.0)",
            "Accept": "application/rss+xml,application/xml,text/xml",
            "Accept-Language": "en-US,en;q=0.8",
        },
    )
    try:
        with urlopen(request, timeout=SEARCH_TIMEOUT_SECONDS) as response:
            xml_data = response.read(2_000_000)
        root = ET.fromstring(xml_data)
        results = []
        for item in root.findall("./channel/item")[:limit]:
            title = " ".join((item.findtext("title") or "").split())
            result_url = (item.findtext("link") or "").strip()
            snippet = " ".join((item.findtext("description") or "").split())
            if title and result_url.startswith(("http://", "https://")):
                results.append({"title": title, "url": result_url, "snippet": snippet})
        return {
            "ok": True,
            "query": query,
            "provider": "Bing Search RSS",
            "results": results,
            "result_count": len(results),
            "duration_ms": round((time.monotonic() - started) * 1000),
        }
    except Exception as exc:
        return {
            "ok": False,
            "query": query,
            "provider": "Bing Search RSS",
            "results": [],
            "error": f"Search failed: {exc}",
            "duration_ms": round((time.monotonic() - started) * 1000),
        }


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def end_headers(self) -> None:
        # Allow index.html opened from file:// or a sandboxed preview to call
        # the explicitly local agent server at 127.0.0.1:8000.
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, x-api-key, anthropic-version")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        super().end_headers()

    def do_OPTIONS(self) -> None:  # noqa: N802
        self.send_response(204)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path == "/api/health":
            body = json.dumps({
                "ok": True,
                "provider": "ai&",
                "model": "qwen/qwen3.6-27b",
                "tools": ["run_command", "web_search", "web_fetch"],
            }).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return
        if path == "/":
            self.path = "/index-fixed.html" if (ROOT / "index-fixed.html").exists() else "/index.html"
        super().do_GET()

    def proxy_aiand(self, path: str, request_body: bytes) -> None:
        is_messages = path == "/api/aiand/messages"
        upstream = AIAND_MESSAGES_UPSTREAM if is_messages else AIAND_CHAT_UPSTREAM
        headers = {"Content-Type": "application/json", "User-Agent": "OpenAI/Python"}
        if is_messages:
            api_key = self.headers.get("x-api-key", "")
            headers.update({"x-api-key": api_key, "anthropic-version": "2023-06-01"})
        else:
            headers["Authorization"] = self.headers.get("Authorization", "")

        request = Request(upstream, data=request_body, method="POST", headers=headers)
        try:
            with urlopen(request, timeout=180) as response:
                self.send_response(response.status)
                self.send_header("Content-Type", response.headers.get("Content-Type", "text/event-stream; charset=utf-8"))
                self.send_header("Cache-Control", "no-cache, no-transform")
                self.send_header("X-Accel-Buffering", "no")
                self.end_headers()
                while True:
                    chunk = response.read(2048)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    self.wfile.flush()
        except HTTPError as exc:
            body = exc.read()
            self.send_response(exc.code)
            self.send_header("Content-Type", exc.headers.get("Content-Type", "application/json"))
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception as exc:
            body = json.dumps({"error": {"type": "proxy_error", "message": str(exc)}}).encode("utf-8")
            self.send_response(502)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        valid_paths = {"/api/run-command", "/api/web-search", "/api/aiand/messages", "/api/aiand/chat"}
        if path not in valid_paths:
            self.send_error(404)
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 5_000_000:
                raise ValueError("Invalid request size.")
            raw_body = self.rfile.read(length)
            if path in {"/api/aiand/messages", "/api/aiand/chat"}:
                self.proxy_aiand(path, raw_body)
                return

            payload = json.loads(raw_body)
            if path == "/api/run-command":
                result = run_command(payload.get("command", ""))
            else:
                result = search_web(payload.get("query", ""), payload.get("max_results", 5))
            body = json.dumps(result, ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
        except Exception as exc:
            body = json.dumps({"ok": False, "error": str(exc)}).encode("utf-8")
            self.send_response(400)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)


if __name__ == "__main__":
    page_url = f"http://{HOST}:{PORT}/index-fixed.html"
    print(f"Claude UI: {page_url}")
    print(f"Restricted command workspace: {WORKSPACE}")
    print("Agent tools: POST /api/run-command, POST /api/web-search")
    print("ai& proxy: POST /api/aiand/messages, POST /api/aiand/chat")
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    if os.environ.get("NO_BROWSER") != "1":
        threading.Timer(0.7, lambda: webbrowser.open(page_url)).start()
    server.serve_forever()
