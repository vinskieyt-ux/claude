# Deploy NVIDIA NIM to Vercel

Required: `index.html`, `api/nvidia-chat.js`, `api/health.js`, `api/web-search.js`, `api/run-command.js`, `lib/nvidia-proxy.js`, and `vercel.json`.

Set `NVIDIA_API_KEY` in Vercel Environment Variables, deploy the whole folder, then verify `/api/health`.
