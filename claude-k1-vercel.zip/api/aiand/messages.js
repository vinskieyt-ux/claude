const { proxyAiand } = require('../../lib/aiand-proxy');

module.exports = async function handler(req, res) {
  return proxyAiand(req, res, 'messages');
};
