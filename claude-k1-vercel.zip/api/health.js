module.exports = async function handler(_req, res) {
  res.setHeader('Cache-Control', 'no-store');
  res.status(200).json({
    ok: true,
    runtime: 'vercel',
    provider: 'ai&',
    model: 'qwen/qwen3.6-27b',
    tools: ['run_command', 'web_search', 'web_fetch'],
  });
};
