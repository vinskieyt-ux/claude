module.exports = async function handler(_req, res) {
  res.setHeader('Cache-Control', 'no-store');
  res.status(200).json({ ok: true, runtime: 'vercel', provider: 'NVIDIA NIM', model: 'moonshotai/kimi-k2.6', tools: ['run_command', 'web_search', 'web_fetch'] });
};
