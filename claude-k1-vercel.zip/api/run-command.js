const fs = require('fs/promises');
const path = require('path');
const dns = require('dns').promises;
const net = require('net');

const ROOT = process.cwd();
const MAX_OUTPUT = 40000;

function tokens(command) {
  return String(command).match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g)?.map((part) => part.replace(/^(["'])|(["'])$/g, '')) || [];
}

function safePath(name = '.') {
  const resolved = path.resolve(ROOT, name);
  if (resolved !== ROOT && !resolved.startsWith(`${ROOT}${path.sep}`)) throw new Error('Path traversal is disabled');
  return resolved;
}

function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
  }
  return ip === '::1' || ip.startsWith('fc') || ip.startsWith('fd') || ip.startsWith('fe80:');
}

async function publicUrl(raw) {
  const match = String(raw).match(/https?:\/\/[^\s"'()\\]+/g);
  if (!match?.length) throw new Error('curl requires a public HTTP(S) URL');
  const url = new URL(match.at(-1).replace(/[.,;]+$/, ''));
  if (url.username || url.password || ['localhost', 'localhost.localdomain'].includes(url.hostname)) throw new Error('Private URLs are disabled');
  const records = await dns.lookup(url.hostname, { all: true });
  if (records.some((record) => isPrivateIp(record.address))) throw new Error('Private network addresses are disabled');
  return url.href;
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ ok: false, error: 'Method not allowed' });
  }

  const started = Date.now();
  const command = String(req.body?.command || '').trim();
  const argv = tokens(command);
  const name = argv[0] || '';
  let stdout = '';
  let stderr = '';
  let returnCode = 0;
  let normalized = command;

  try {
    if (name === 'pwd') {
      stdout = `${ROOT}\n`;
    } else if (name === 'ls') {
      const target = safePath(argv.slice(1).find((arg) => !arg.startsWith('-')) || '.');
      const entries = await fs.readdir(target, { withFileTypes: true });
      stdout = `${entries.map((entry) => entry.name + (entry.isDirectory() ? '/' : '')).join('\n')}\n`;
    } else if (['cat', 'head', 'tail', 'wc', 'grep'].includes(name)) {
      const filename = argv.at(-1);
      const content = await fs.readFile(safePath(filename), 'utf8');
      const lines = content.split(/\r?\n/);
      if (name === 'cat') stdout = content;
      if (name === 'head') stdout = lines.slice(0, 10).join('\n');
      if (name === 'tail') stdout = lines.slice(-10).join('\n');
      if (name === 'wc') stdout = `${lines.length} ${content.split(/\s+/).filter(Boolean).length} ${content.length} ${filename}\n`;
      if (name === 'grep') stdout = `${lines.filter((line) => line.includes(argv[1] || '')).join('\n')}\n`;
    } else if (name === 'echo') {
      stdout = `${argv.slice(1).join(' ')}\n`;
    } else if (name === 'curl') {
      const url = await publicUrl(command.replace(/\\[\])]/g, ''));
      normalized = `curl -sS -L --max-time 10 ${JSON.stringify(url)}`;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 10000);
      const response = await fetch(url, { redirect: 'follow', signal: controller.signal });
      clearTimeout(timeout);
      stdout = await response.text();
      if (!response.ok) returnCode = 22;
    } else {
      throw new Error(`Command '${name}' is not available in the Vercel sandbox`);
    }
  } catch (error) {
    stderr = error instanceof Error ? error.message : String(error);
    returnCode = 1;
  }

  if (stdout.length + stderr.length > MAX_OUTPUT) stdout = `${stdout.slice(0, MAX_OUTPUT)}\n[truncated]`;
  res.setHeader('Cache-Control', 'no-store');
  res.status(200).json({
    ok: returnCode === 0,
    command: normalized,
    stdout,
    stderr,
    return_code: returnCode,
    duration_ms: Date.now() - started,
  });
};
