const { proxyNvidia } = require('../lib/nvidia-proxy');
module.exports = async (req, res) => proxyNvidia(req, res);
