#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for file in index.html api/health.js api/nvidia-chat.js api/web-search.js api/run-command.js lib/nvidia-proxy.js vercel.json; do test -f "$file" || exit 1; done
npx vercel --prod
